Castel of the Secret 
- It is a puzzle game. In the game, you must find vampire to kill him. There are many rooms in the map and each room connecting other room. Some room has warming message to give you information of the next room.

Game elements 
- Object 
- Monsters
- Warning message

Features
- Mini game: Rock Paper Scissors

Write in
- C# MVC
